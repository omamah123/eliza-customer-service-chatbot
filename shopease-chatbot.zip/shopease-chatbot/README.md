# ShopEase Chatbot

A React-based customer support chatbot for ShopEase.

## Quick Start

### 1. Install dependencies
```bash
npm install
```

### 2. Run locally
```bash
npm run dev
```
Open http://localhost:5173

### 3. Build for production
```bash
npm run build
```
This creates a `dist/` folder with static files ready to deploy.

---

## Deployment Options

### Option A: Netlify (easiest — drag & drop)
1. Run `npm run build`
2. Go to [netlify.com](https://netlify.com) → "Add new site" → "Deploy manually"
3. Drag the `dist/` folder into the browser
4. ✅ Live in seconds, free tier available

### Option B: Vercel
1. Push this project to a GitHub repo
2. Go to [vercel.com](https://vercel.com) → "New Project" → Import your repo
3. Set Framework Preset to **Vite** — it auto-detects
4. Click Deploy ✅

### Option C: GitHub Pages
1. Install the plugin: `npm install --save-dev gh-pages`
2. Add to `package.json` scripts: `"deploy": "gh-pages -d dist"`
3. Add to `vite.config.ts`: `base: '/your-repo-name/'`
4. Run: `npm run build && npm run deploy`

### Option D: Any Static Host (AWS S3, Apache, Nginx)
1. Run `npm run build`
2. Upload the contents of `dist/` to your server's web root
3. For Nginx, add this to your config to support client-side routing:
```nginx
location / {
  try_files $uri $uri/ /index.html;
}
```

---

## Customisation

Edit constants at the top of `src/App.tsx`:
```ts
const STORE_NAME = "ShopEase";
const SUPPORT_EMAIL = "support@shopease.example.com";
const RETURNS_PORTAL = "shopease.example.com/returns";
const TRACKING_URL = "shopease.example.com/track";
```

## Requirements
- Node.js 18+
- npm 9+
