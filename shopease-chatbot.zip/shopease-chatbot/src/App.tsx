/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import React, { useState, useEffect, useRef } from 'react';
import { Send, RotateCcw, Truck, HelpCircle, Package, RefreshCcw, Bot, User } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// --- Chatbot Logic Constants ---
const STORE_NAME = "ShopEase";
const SUPPORT_EMAIL = "support@shopease.example.com";
const RETURNS_PORTAL = "shopease.example.com/returns";
const TRACKING_URL = "shopease.example.com/track";

const REFLECTIONS: Record<string, string> = {
  "i'm": "you're",
  "i've": "you've",
  "i'll": "you'll",
  "i'd": "you'd",
  "i": "you",
  "me": "you",
  "my": "your",
  "mine": "yours",
  "am": "are",
  "was": "were",
  "we're": "you're",
  "we've": "you've",
  "we'll": "you'll",
  "we": "you",
  "us": "you",
  "our": "your",
  "ours": "yours",
  "myself": "yourself",
  "ourselves": "yourselves",
};

function reflect(text: string): string {
  const words = text.toLowerCase().split(/\s+/);
  return words.map(word => {
    const cleanWord = word.replace(/[.,!?]$/, "");
    const punctuation = word.slice(cleanWord.length);
    if (REFLECTIONS[cleanWord]) {
      return REFLECTIONS[cleanWord] + punctuation;
    }
    return word;
  }).join(" ");
}

type PatternResponse = [RegExp, string[]];

const PATTERNS: PatternResponse[] = [
  [
    /^\s*#?(\d{3,})\s*$/i,
    ["__ORDER_NUMBER_FOLLOWUP__"]
  ],
  [
    /^\s*(?:hello+|hi+|hey+|good\s+(?:morning|afternoon|evening))\b(.*)/i,
    [
      `Hey there! Welcome to ${STORE_NAME} support. Are you checking on an order, looking for a refund, or something else?`,
      `Hi! Thanks for reaching out to ${STORE_NAME}. What can I help you with today?`,
      `Hello and welcome to ${STORE_NAME}! How can I make your day better?`,
    ]
  ],
  [
    /.*\bmy name(?:'?s| is)\s+([\w]+)/i,
    [
      `Nice to meet you, {0}! I'm the ${STORE_NAME} virtual assistant. What can I help you with?`,
      `Welcome, {0}! How can ${STORE_NAME} help you today?`,
    ]
  ],
  [
    /(.*\b(?:order|#)\b.*?#?\s*(\d{3,}).*)/i,
    [
      `I can see that {0}. Let me pull up order #{1} right now — could you confirm the email on your ${STORE_NAME} account?`,
      `Got it — {0}. I'm on it! Live tracking is also at ${TRACKING_URL}.`,
      `I understand {0}. Give me a moment to check order #{1} for you.`,
    ]
  ],
  [
    /(i\b.*?\b(?:haven'?t|have\s+not|didn'?t|not\s+yet|still\s+waiting|never)\b.*?\b(?:received|arrived|come|shown\s+up|delivered|here|turned\s+up)\b.*)/i,
    [
      "I see that {0}. That's frustrating — could you share your order number so I can investigate?",
      "I understand that {0}. Let me look into this for you — what is your order number?",
      `I'm sorry that {0}. Deliveries can sometimes be delayed — share your order number and I'll chase it with the courier immediately.`,
    ]
  ],
  [
    /(i\b.*?(?:still|not|never)\b.*?\b(?:order|package|parcel|delivery)\b.*)/i,
    [
      "I can see that {0}. Could you share your order number so I can look into it?",
      "I understand that {0}. Let me check what's happened — what's your order number?",
    ]
  ],
  [
    /.*\b(?:track|where|status|find|locate)\b.*\b(?:order|package|parcel|delivery|shipment)\b(.*)/i,
    [
      `Happy to help! Could you share your order number so I can pull up the latest tracking info? You can also visit ${TRACKING_URL} directly.`,
      "Sure — what's your order number? I'll pull up the latest shipping status right away.",
    ]
  ],
  [
    /.*\b(?:return|send\s+back|sending\s+back|give\s+back)\b\s+(.*)/i,
    [
      `Of course — I can help you return {0}. Head to ${RETURNS_PORTAL} for a free prepaid label, or share your order number and I'll start the process here.`,
      `Returning {0} is easy. Visit ${RETURNS_PORTAL} or drop your order number here.`,
      "Sure — returning {0} is straightforward. Could you share your order number so I can get that started?",
    ]
  ],
  [
    /.*\b(?:return|send\s+back)\b(.*)/i,
    [
      `Happy to help with a return! Visit ${RETURNS_PORTAL} or share your order number here and I'll get it sorted.`,
      `Returns at ${STORE_NAME} are easy — head to ${RETURNS_PORTAL} for a free prepaid label.`,
    ]
  ],
  [
    /(?:i\b.*?\b)?((?:refund|money\s+back|reimburs\w+|paid\s+too\s+much).*)/i,
    [
      "I understand you're asking about a {0}. Refunds are processed within 3–5 business days. Could you share your order number so I can raise this?",
      "I can certainly help you with that {0}. I'll get that sorted — what's your order number and the reason for the refund?",
    ]
  ],
  [
    /(i\b.*?\b(?:damaged|broken|faulty|defective|wrong\s+item|incorrect|not\s+what\s+i\s+ordered)\b.*)/i,
    [
      "I'm really sorry that {0}. That's completely unacceptable. Please share your order number and a photo if possible — I'll arrange a replacement or full refund immediately.",
      "I can see that {0}. This shouldn't happen. Give me your order number and I'll sort a replacement or refund right away.",
    ]
  ],
  [
    /.*\b(damaged|broken|faulty|defective|wrong)\b.*\b(?:arrived|delivered|received|came)\b(.*)/i,
    [
      "I'm sorry to hear a {0} item arrived — that's not acceptable. Could you share your order number so I can arrange a replacement or refund?",
      "Receiving a {0} item is completely unacceptable. Please share your order number and I'll resolve this immediately.",
    ]
  ],
  [
    /.*\b(?:promo(?:\s+code)?|discount|voucher|coupon|offer\s+code)\b(.*)/i,
    [
      `${STORE_NAME} regularly runs promotions! Sign up at shopease.example.com for 10% off your next order. Do you have a specific code that isn't working?`,
      "If your promo code isn't applying at checkout, check it hasn't expired and that your basket meets the minimum spend. Share the code here and I'll look into it!",
      `We do have discounts and offers available! You can find all current deals at shopease.example.com/offers, or sign up to our newsletter for exclusive codes.`,
    ]
  ],
  [
    /.*\b(?:add|put|place)\b\s+(.*?)\s+\b(?:in|into|to)\b.*\b(cart|basket|bag)\b(.*)/i,
    [
      "Great choice! I can't directly modify your {1} from this chat, but you can easily add {0} by searching for it on shopease.example.com.",
      "I see you want to put {0} in your {1}. Just head over to the product page on our site and click 'Add to {1}' to grab it!",
      "To add {0} to your {1}, please visit shopease.example.com. Is there anything else you need help finding today?",
    ]
  ],
  [
    /.*\b(?:how\s+do\s+i|where\s+do\s+i)\b.*\b(?:add|put|place)\b.*\b(?:cart|basket|bag)\b(.*)/i,
    [
      "To add an item to your cart, just go to the product's page on shopease.example.com, select your size or color, and click the big 'Add to Cart' button!",
    ]
  ],
  [
    /.*\b(?:forgot(?:ten)?|reset|lost)\b.*\b(?:password|login|credentials)\b(.*)/i,
    [
      `No problem — just click 'Forgot Password' on the ${STORE_NAME} login page and we'll email you a reset link within a minute.`,
      `Easy fix! Hit 'Forgot Password' on the login page. If the email doesn't arrive within 5 minutes, check your spam folder or email us at ${SUPPORT_EMAIL}.`,
    ]
  ],
  [
    /(i\b.*?\b(?:can'?t|cannot|unable\s+to|trouble|problem|issue)\b.*?\b(?:log\s*in|login|sign\s*in|access\s+my\s+account)\b.*)/i,
    [
      `I'm sorry that {0}. Try the 'Forgot Password' link on the login page. If that doesn't work, email ${SUPPORT_EMAIL} with your registered address and we'll reset it manually.`,
      "I can see that {0}. Account access issues are usually fixed with a quick password reset — have you tried 'Forgot Password'?",
    ]
  ],
  [
    /.*\b(?:accept|take|pay\s+with)\b\s+(paypal|credit\s+card|debit\s+card|apple\s+pay|google\s+pay|klarna|afterpay|cash)\b(.*)/i,
    [
      "Yes, we accept {0} at checkout! You'll see the option when you are ready to complete your order.",
      "You can definitely use {0} for your purchase. We also accept most other major payment methods.",
    ]
  ],
  [
    /.*\b(?:payment\s+methods?|how\s+(?:can|do)\s+(?:i|we)\s+pay|options\s+to\s+pay)\b(.*)/i,
    [
      "We accept all major credit and debit cards, PayPal, Apple Pay, and Google Pay. You'll see all available payment methods at the checkout page.",
      "You can pay using Visa, Mastercard, American Express, PayPal, and Apple Pay. Is there a specific method you were hoping to use?",
    ]
  ],
  [
    /(i\b.*?\b(?:change|update|edit|modify)\b.*?\b(?:address|email|phone|number|payment|card)\b.*)/i,
    [
      `I understand that {0}. You can make that change in 'Account Settings' once logged in. If you're stuck, email ${SUPPORT_EMAIL} and we'll update it for you.`,
      "I can see that {0}. Head to Account Settings — it should only take a moment. Anything stopping you from getting in?",
    ]
  ],
  [
    /.*\b(?:how\s+long|when\s+will|when\s+can|estimated|expected|how\s+soon)\b.*\b(?:deliver|shipping|arrive|receipt|receive|dispatch|sent|get\s+my)\b(.*)/i,
    [
      `Standard delivery at ${STORE_NAME} takes 3–5 business days; express is 1–2 days. You'll get a tracking email as soon as your order is dispatched.`,
      "Delivery times depend on your location and chosen shipping method. Do you have an order number I can check the dispatch status on?",
    ]
  ],
  [
    /.*\b(?:in\s+stock|available|back\s+in\s+stock|do\s+you\s+(?:have|sell|carry|stock))\b\s*(.*)/i,
    [
      "Stock levels change daily! Check the product page on shopease.example.com and click 'Notify Me' to get an email the moment it's back.",
      "For up-to-date stock info the product page is your best bet. Want me to flag this with our stock team?",
    ]
  ],
  [
    /.*\b(?:looking\s+for|any|need|want\s+to\s+buy|shopping\s+for)\b\s+(\w[\w\s]*?)\b(?:\?|$|\.)/i,
    [
      `We carry a wide range of {0}! Browse shopease.example.com to see the full selection. Want me to flag a specific item or size for a stock alert?`,
      `Great choice — we stock {0} across several brands. Head to shopease.example.com/search?q={0} or I can flag the item for a 'back in stock' notification.`,
    ]
  ],
  [
    /(i\b.*?\b(?:frustrated|unhappy|angry|disappointed|upset|annoyed|furious|not\s+happy)\b.*)/i,
    [
      `I'm truly sorry to hear {0}. That's not the ${STORE_NAME} experience we want for you — please tell me more and I'll do everything I can to put it right.`,
      "I understand {0}. Your feelings are completely valid and I want to fix this. Can you give me a bit more detail?",
      "I hear that {0}. I apologise — please share your order number or describe the issue and I'll escalate it immediately.",
    ]
  ],
  [
    /(.*\b(?:terrible|awful|horrible|rubbish|poor|disgusting|useless|dreadful)\b.*)/i,
    [
      `I'm really sorry you feel that {0}. That's not the standard ${STORE_NAME} stands for — could you tell me what happened so I can escalate it?`,
      "I hear you that {0}. I sincerely apologise — please describe what went wrong and I'll make sure it reaches the right team.",
    ]
  ],
  [
    /(i\b.*?\b(?:problem|issue|trouble|concern)\b.*)/i,
    [
      "I can see that {0}. I'm sorry to hear that — could you give me a bit more detail and your order number if relevant?",
      "I understand that {0}. Let's sort this out together. What exactly is going wrong?",
    ]
  ],
  [
    /(i\b.*?\b(?:love|amazing|excellent|fantastic|brilliant|happy\s+with|impressed|wonderful)\b.*)/i,
    [
      `That's so wonderful to hear that {0}! We'll pass your kind words on to the team. Thanks for shopping with ${STORE_NAME}! 🎉`,
      `It's brilliant to hear that {0}. Feedback like this really makes our day at ${STORE_NAME}!`,
    ]
  ],
  [
    /.*\b(?:can|could)\b\s+(?:you|u)\s+(.*)/i,
    [
      "I think I can {0}. I'm an automated assistant, but I'll do my best!",
      "I'm programmed to help with orders and returns. I can certainly try to {0}.",
      "I can help you with most ShopEase tasks. Ask me specifically about your order!",
    ]
  ],
  [
    /^\s*why\b\s+(.*)/i,
    [
      "That's a good question. Why do you think {0}?",
      "I'm not sure why {0}, but I can look into it if you have an order number.",
      "The reason {0} usually depends on stock or shipping delays. Can I check your order?",
    ]
  ],
  [
    /.*\b(?:mean|meant)\b\s+(.*)/i,
    [
      "Oh, I see! You meant {0}. Thanks for clarifying.",
      "Understood. Since you meant {0}, let's try to sort that out.",
    ]
  ],
  [
    /.*\b(?:bye|goodbye|see\s+you|cheers|thank?\s*you|thanks|thx|ty)\b(.*)/i,
    [
      `Thanks for reaching out to ${STORE_NAME}! Have a brilliant day. 👋`,
      "It was a pleasure helping you today. Happy shopping!",
      `Goodbye! If you ever need anything else, ${STORE_NAME} support is always here.`,
    ]
  ]
];

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'bot';
  timestamp: Date;
}

export default function App() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: `Hi! Welcome to ${STORE_NAME} support. How can I help you today?`,
      sender: 'bot',
      timestamp: new Date(),
    }
  ]);
  const [input, setInput] = useState('');
  const [lastTopic, setLastTopic] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  const handleSend = () => {
    if (!input.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: input,
      sender: 'user',
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    const currentInput = input;
    setInput('');
    setIsTyping(true);

    setTimeout(() => {
      const botResponse = getBotResponse(currentInput);
      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: botResponse,
        sender: 'bot',
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, botMessage]);
      setIsTyping(false);
    }, 800);
  };

  const getBotResponse = (userInput: string): string => {
    const trimmedInput = userInput.trim();

    for (const [pattern, responses] of PATTERNS) {
      const match = trimmedInput.match(pattern);
      if (match) {
        if (responses[0] === "__ORDER_NUMBER_FOLLOWUP__") {
          const orderNum = match[1];
          let reply = "";
          if (lastTopic === "tracking") {
            reply = [
              `Thanks! I'm pulling up order #${orderNum} right now — I'll have an update for you in a moment.`,
              `Got it — looking into order #${orderNum} for you. Could you also confirm the email on your ${STORE_NAME} account?`,
            ][Math.floor(Math.random() * 2)];
          } else if (lastTopic === "refund") {
            reply = [
              `Perfect — I've noted order #${orderNum}. Your refund request is being raised now and will be processed within 3–5 business days.`,
              `Thanks! Refund for order #${orderNum} is being processed. You'll get a confirmation email shortly.`,
            ][Math.floor(Math.random() * 2)];
          } else if (lastTopic === "return") {
            reply = [
              `Great — I've got order #${orderNum}. I'm generating your free prepaid return label now and will email it to you shortly.`,
              `Thanks! Return label for order #${orderNum} is on its way to your inbox.`,
            ][Math.floor(Math.random() * 2)];
          } else {
            reply = [
              `Thanks for that — looking into order #${orderNum} for you now.`,
              `Got it! I'll check order #${orderNum} and get back to you.`,
            ][Math.floor(Math.random() * 2)];
          }
          setLastTopic('');
          return reply;
        }

        const reflectedGroups = match.slice(1).map(g => reflect(g?.trim() || ""));
        let template = responses[Math.floor(Math.random() * responses.length)];
        let reply = template;
        reflectedGroups.forEach((val, i) => {
          reply = reply.replace(`{${i}}`, val);
        });

        if (reply.toLowerCase().includes("order number")) {
          const lowerInput = trimmedInput.toLowerCase();
          if (["track", "where", "status", "arrived", "received", "delivery"].some(w => lowerInput.includes(w))) {
            setLastTopic("tracking");
          } else if (["refund", "money back", "reimburs"].some(w => lowerInput.includes(w))) {
            setLastTopic("refund");
          } else if (["return", "send back"].some(w => lowerInput.includes(w))) {
            setLastTopic("return");
          } else {
            setLastTopic("general");
          }
        }

        return reply;
      }
    }

    if (trimmedInput.includes("?")) {
      return [
        "That's an interesting question. I'm not sure I have the exact answer, but have you checked our FAQ at shopease.example.com/help?",
        "I'm not completely sure about that. Could you try asking it differently or share an order number?",
      ][Math.floor(Math.random() * 2)];
    }

    return [
      "I'm not quite sure I understood that. Could you rephrase it or give me a bit more detail?",
      "I'm still learning and might have missed your point! Could you describe the issue differently?",
      `I want to help, but I'm having trouble understanding. You can also email us at ${SUPPORT_EMAIL}.`,
    ][Math.floor(Math.random() * 3)];
  };

  const resetChat = () => {
    setMessages([
      {
        id: Date.now().toString(),
        text: `Hi! Welcome to ${STORE_NAME} support. How can I help you today?`,
        sender: 'bot',
        timestamp: new Date(),
      }
    ]);
    setInput('');
    setLastTopic('');
  };

  return (
    <div style={{
      minHeight: '100vh',
      background: 'linear-gradient(135deg, #eff6ff 0%, #f8fafc 50%, #f0fdf4 100%)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '16px',
    }}>
      <div style={{
        width: '100%',
        maxWidth: '480px',
        background: 'white',
        borderRadius: '24px',
        boxShadow: '0 20px 60px rgba(0,0,0,0.12), 0 4px 16px rgba(0,0,0,0.06)',
        display: 'flex',
        flexDirection: 'column',
        overflow: 'hidden',
        height: '680px',
      }}>

        {/* Header */}
        <div style={{
          background: 'linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%)',
          padding: '20px 20px 16px',
          color: 'white',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
              <div style={{
                width: '44px', height: '44px', borderRadius: '14px',
                background: 'rgba(255,255,255,0.2)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                <Bot size={22} color="white" />
              </div>
              <div>
                <div style={{ fontWeight: 700, fontSize: '16px' }}>{STORE_NAME} Support</div>
                <div style={{ fontSize: '12px', opacity: 0.85, display: 'flex', alignItems: 'center', gap: '6px' }}>
                  <span style={{
                    width: '7px', height: '7px', borderRadius: '50%',
                    background: '#4ade80', display: 'inline-block',
                  }} />
                  Online & Ready to Help
                </div>
              </div>
            </div>
            <button
              onClick={resetChat}
              title="Reset chat"
              style={{
                background: 'rgba(255,255,255,0.15)',
                border: 'none',
                borderRadius: '10px',
                padding: '8px',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: '6px',
                color: 'white',
                fontSize: '12px',
              }}
            >
              <RotateCcw size={14} />
              Reset
            </button>
          </div>

          {/* Quick Actions */}
          <div style={{
            display: 'flex', gap: '8px', marginTop: '14px',
            overflowX: 'auto', paddingBottom: '2px',
          }}>
            {[
              { icon: Truck, label: 'Track Order', query: 'Where is my order?' },
              { icon: RefreshCcw, label: 'Returns', query: 'How do I return an item?' },
              { icon: Package, label: 'Stock Info', query: 'Is this item in stock?' },
              { icon: HelpCircle, label: 'Help', query: 'I need help with my account' },
            ].map((action, i) => (
              <button
                key={i}
                onClick={() => setInput(action.query)}
                style={{
                  display: 'flex', alignItems: 'center', gap: '6px',
                  padding: '6px 12px',
                  background: 'rgba(255,255,255,0.15)',
                  border: '1px solid rgba(255,255,255,0.3)',
                  borderRadius: '999px',
                  color: 'white',
                  fontSize: '12px',
                  fontWeight: 500,
                  cursor: 'pointer',
                  whiteSpace: 'nowrap',
                  transition: 'background 0.2s',
                }}
                onMouseEnter={e => (e.currentTarget.style.background = 'rgba(255,255,255,0.25)')}
                onMouseLeave={e => (e.currentTarget.style.background = 'rgba(255,255,255,0.15)')}
              >
                <action.icon size={13} />
                {action.label}
              </button>
            ))}
          </div>
        </div>

        {/* Chat Area */}
        <div
          ref={scrollRef}
          style={{
            flex: 1,
            overflowY: 'auto',
            padding: '20px',
            display: 'flex',
            flexDirection: 'column',
            gap: '14px',
            background: '#f8fafc',
          }}
        >
          <AnimatePresence initial={false}>
            {messages.map((msg) => (
              <motion.div
                key={msg.id}
                initial={{ opacity: 0, y: 12, scale: 0.97 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.2 }}
                style={{
                  display: 'flex',
                  flexDirection: msg.sender === 'user' ? 'row-reverse' : 'row',
                  alignItems: 'flex-end',
                  gap: '8px',
                }}
              >
                {/* Avatar */}
                <div style={{
                  width: '30px', height: '30px', borderRadius: '10px', flexShrink: 0,
                  background: msg.sender === 'user'
                    ? 'linear-gradient(135deg, #6366f1, #8b5cf6)'
                    : 'linear-gradient(135deg, #2563eb, #1d4ed8)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}>
                  {msg.sender === 'user'
                    ? <User size={15} color="white" />
                    : <Bot size={15} color="white" />}
                </div>

                <div style={{ maxWidth: '75%' }}>
                  <div style={{
                    padding: '10px 14px',
                    borderRadius: msg.sender === 'user' ? '18px 18px 4px 18px' : '18px 18px 18px 4px',
                    background: msg.sender === 'user'
                      ? 'linear-gradient(135deg, #2563eb, #1d4ed8)'
                      : 'white',
                    color: msg.sender === 'user' ? 'white' : '#1e293b',
                    fontSize: '14px',
                    lineHeight: '1.5',
                    boxShadow: '0 2px 8px rgba(0,0,0,0.07)',
                  }}>
                    {msg.text}
                  </div>
                  <div style={{
                    fontSize: '11px', color: '#94a3b8', marginTop: '4px',
                    textAlign: msg.sender === 'user' ? 'right' : 'left',
                  }}>
                    {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>

          {isTyping && (
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              style={{ display: 'flex', alignItems: 'flex-end', gap: '8px' }}
            >
              <div style={{
                width: '30px', height: '30px', borderRadius: '10px',
                background: 'linear-gradient(135deg, #2563eb, #1d4ed8)',
                display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
              }}>
                <Bot size={15} color="white" />
              </div>
              <div style={{
                background: 'white', borderRadius: '18px 18px 18px 4px',
                padding: '12px 16px', display: 'flex', gap: '5px', alignItems: 'center',
                boxShadow: '0 2px 8px rgba(0,0,0,0.07)',
              }}>
                {[0, 0.2, 0.4].map((delay, i) => (
                  <motion.div
                    key={i}
                    style={{ width: '7px', height: '7px', borderRadius: '50%', background: '#93c5fd' }}
                    animate={{ y: [0, -5, 0] }}
                    transition={{ repeat: Infinity, duration: 0.7, delay }}
                  />
                ))}
              </div>
            </motion.div>
          )}
        </div>

        {/* Input Area */}
        <div style={{
          padding: '16px',
          borderTop: '1px solid #e2e8f0',
          background: 'white',
        }}>
          <div style={{ position: 'relative' }}>
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Type your message here..."
              style={{
                width: '100%',
                padding: '12px 50px 12px 16px',
                background: '#f8fafc',
                border: '1.5px solid #e2e8f0',
                borderRadius: '14px',
                fontSize: '14px',
                outline: 'none',
                transition: 'border-color 0.2s',
                boxSizing: 'border-box',
              }}
              onFocus={e => (e.target.style.borderColor = '#2563eb')}
              onBlur={e => (e.target.style.borderColor = '#e2e8f0')}
            />
            <button
              onClick={handleSend}
              disabled={!input.trim()}
              style={{
                position: 'absolute', right: '8px', top: '50%',
                transform: 'translateY(-50%)',
                width: '34px', height: '34px', borderRadius: '10px',
                background: input.trim() ? 'linear-gradient(135deg, #2563eb, #1d4ed8)' : '#e2e8f0',
                border: 'none', cursor: input.trim() ? 'pointer' : 'default',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                transition: 'background 0.2s',
              }}
            >
              <Send size={15} color={input.trim() ? 'white' : '#94a3b8'} />
            </button>
          </div>
          <p style={{
            textAlign: 'center', fontSize: '11px', color: '#94a3b8', marginTop: '10px',
          }}>
            Powered by {STORE_NAME} AI Assistant • Standard response times apply
          </p>
        </div>
      </div>
    </div>
  );
}
